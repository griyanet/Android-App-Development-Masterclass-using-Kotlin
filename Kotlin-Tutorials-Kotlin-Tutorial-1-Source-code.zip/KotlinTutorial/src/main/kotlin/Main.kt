fun main(args: Array<String>) {
    println("Hello World")
    println("My first Kotlin program")
}