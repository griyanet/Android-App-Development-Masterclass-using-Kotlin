/**
 * Created by timbuchalka for Android Oreo with Kotlin course
 * from www.learnprogramming.academy
 */
class Troll(name: String) : Enemy(name, 27, 1) {

}