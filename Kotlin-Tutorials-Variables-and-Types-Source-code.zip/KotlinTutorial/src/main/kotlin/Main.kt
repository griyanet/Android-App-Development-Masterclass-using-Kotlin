fun main(args: Array<String>) {
    println("Hello World")
    println("My first Kotlin program")

    var tim: String
    tim = "Tim Buchalka"
    println(tim)

    var timSalary: Int = 32
    var monthly: Int = timSalary * 4
    println(timSalary)
    println(monthly)
}